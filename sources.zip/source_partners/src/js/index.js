const search = document.querySelector('.header__search')
const searchPopUp = document.querySelector('.search_popUp')

search.addEventListener('click', () => {
    searchPopUp.style.display = "block"
})

searchPopUp.addEventListener('click', (event) => {
    if(event.target.classList.contains('search_popUp')){
        searchPopUp.style.display = "none"
    }
    if(event.target.classList.contains('search__popUp_icon')){
        console.log('Ушел запрос на поиск');
    }
})